/*-----------------------------------------------------------------------------------
    Template Name: Crypto Max
    Description: Crypto Max - Bitcoin and Cryptocurrency Responsive HTML5 Template
    Author: Codezion
    Author URI: https://www.templatemonster.com/authors/codezion/
    Version: 1.0
-----------------------------------------------------------------------------------*/
(function($) {
    'use strict';
    // Preloader
    $(window).on('load', function() {
        $('.preloader').addClass('hidden');
        $('[data-popup="tooltip"]').tooltip();
    });
    $(".hamburger>.hamburger_btn").on('click', function() {
        $(".header .navigation").toggleClass('open');
        $(this).toggleClass('active');
    });
    // Mobile Menu
    $(".header .menu-item-has-children > a").on('click', function(e) {
        var submenu = $(this).next(".sub-menu");
        e.preventDefault();
        submenu.slideToggle(200);
    });
    // Popup Video
    $('.popup_video').magnificPopup({
        type: 'iframe',
    });
    // banner_slider
    $('.banner_slider').slick({
        dots: false,
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        infinite: true,
        rtl: rtl_slick(),
    });
    // movie_slider
    $('.movie_slider').slick({
        dots: false,
        arrows: false,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        infinite: true,
        rtl: rtl_slick(),
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 3
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 2
            }
        }, {
            breakpoint: 500,
            settings: {
                slidesToShow: 1
            }
        }]
    });
    // show_slider
    $('.show_slider').slick({
        dots: false,
        arrows: false,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        infinite: true,
        rtl: rtl_slick(),
        responsive: [{
            breakpoint: 1200,
            settings: {
                slidesToShow: 3
            }
        }, {
            breakpoint: 992,
            settings: {
                slidesToShow: 2
            }
        }, {
            breakpoint: 500,
            settings: {
                slidesToShow: 1
            }
        }]
    });
    // show_slider
    $('.new_releases_slider').slick({
        dots: false,
        arrows: false,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        infinite: false,
        rtl: rtl_slick(),
        responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 2
            }
        }, {
            breakpoint: 576,
            settings: {
                slidesToShow: 1
            }
        }]
    });
    //  Scroll back to top
    var pageHeight = document.querySelector('.backtotop path');
    var pageLength = pageHeight.getTotalLength();
    pageHeight.style.transition = pageHeight.style.WebkitTransition = 'none';
    pageHeight.style.strokeDasharray = pageLength + ' ' + pageLength;
    pageHeight.style.strokeDashoffset = pageLength;
    pageHeight.getBoundingClientRect();
    pageHeight.style.transition = pageHeight.style.WebkitTransition = 'stroke-dashoffset 10ms linear';
    var updateProgress = function() {
        var scroll = $(window).scrollTop();
        var height = $(document).height() - $(window).height();
        var progress = pageLength - (scroll * pageLength / height);
        pageHeight.style.strokeDashoffset = progress;
    }
    updateProgress();
    $(window).scroll(updateProgress);
    var offset = 150;
    var duration = 550;
    jQuery(window).on('scroll', function() {
        if (jQuery(this).scrollTop() > offset) {
            jQuery('.backtotop').addClass('active');
        } else {
            jQuery('.backtotop').removeClass('active');
        }
    });
    jQuery('.backtotop').on('click', function(event) {
        event.preventDefault();
        jQuery('html, body').animate({ scrollTop: 0 }, duration);
        return false;
    })
    // Current year
    var d = new Date();
    document.getElementById("year").innerHTML = d.getFullYear();

    function rtl_slick() {
        if ($('html').is("[dir='rtl']")) {
            return true;
        } else {
            return false;
        }
    }

})(jQuery);